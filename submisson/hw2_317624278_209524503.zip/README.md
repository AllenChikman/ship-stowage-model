# Bonus
For more Information please read the bonus.txt

# Folder Hierarchy

#### simulator/
##### makefile: 
the following commands (from main folder) will generate the simulator executable:
- cd simulator
- make

#### algorithm/

##### makefile: 
the following commands (from main folder) shall generate the 2 .so files:
cd algorithm
make
  
#### common/
holds the common files between the algorithm and the simulation

#### interfaces/
hold the given header interfaces, and their cpp implementation