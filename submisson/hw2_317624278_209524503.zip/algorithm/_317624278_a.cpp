//
// Created by Allen on 19/05/2020.
//

#include "_317624278_a.h"

#ifdef LINUX_ENV
REGISTER_ALGORITHM(_317624278_a)
#endif