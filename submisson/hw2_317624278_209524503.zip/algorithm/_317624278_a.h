//
// Created by Allen on 19/05/2020.
//

#ifndef SHIP_STOWAGE_MODEL_317624278_A_H
#define SHIP_STOWAGE_MODEL_317624278_A_H


#include "NaiveAlgorithm.h"
#include "../common/EnviormentConfig.h"
#include "../interfaces/AlgorithmRegistration.h"

class _317624278_a : public NaiveAlgorithm
{
};


#endif //SHIP_STOWAGE_MODEL_317624278_A_H
