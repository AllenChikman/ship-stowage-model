#ifndef SHIP_STOWAGE_MODEL_ENVIORMENTCONFIG_H
#define SHIP_STOWAGE_MODEL_ENVIORMENTCONFIG_H

/*If running on windows, comment the define below to make the build successful*/
#define LINUX_ENV

#endif //SHIP_STOWAGE_MODEL_ENVIORMENTCONFIG_H
